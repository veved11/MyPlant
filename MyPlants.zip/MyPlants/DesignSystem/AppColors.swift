import SwiftUI

// ألوان موحّدة تستخدمها شاشات ومكوّنات التطبيق.
enum AppColors {
    // خلفية الشاشات الرئيسية.
    static let background = Color(hex: 0x000000)

    // خلفيات الحقول والبطاقات الداكنة.
    static let surface = Color(hex: 0x18181D)
    static let surfaceSecondary = Color(hex: 0x222224)

    // اللون التركوازي للأزرار وحالات الإنجاز.
    static let primary = Color(hex: 0x26C391)
    static let mint = Color(hex: 0x28E0A8)

    // ألوان شارات الإضاءة وكمية الماء.
    static let sunlight = Color(hex: 0xCEDE89)
    static let water = Color(hex: 0xCAF3FB)

    // ألوان النصوص والفواصل.
    static let secondaryText = Color(hex: 0x8E8E93)
    static let mutedText = Color(hex: 0x989898)
    static let divider = Color.white.opacity(0.18)
}

// يحوّل قيمة اللون بصيغة Hex إلى لون SwiftUI.
extension Color {
    init(hex: UInt32) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: 1
        )
    }
}
