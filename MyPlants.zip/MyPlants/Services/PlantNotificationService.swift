import Foundation
import UserNotifications

final class PlantNotificationService {
    static let shared = PlantNotificationService()

    private let notificationCenter = UNUserNotificationCenter.current()

    private init() {}

    func requestPermission() async -> Bool {
        do {
            return try await notificationCenter.requestAuthorization(
                options: [.alert, .sound, .badge]
            )
        } catch {
            return false
        }
    }

    func scheduleReminder(
        for plant: PlantReminder,
        identifier: UUID? = nil
    ) async {
        let permissionGranted = await requestPermission()
        guard permissionGranted else { return }

        let content = UNMutableNotificationContent()
        content.title = "MyPlants"
        content.body = "Hey! Let’s water your \(plant.name) 🌱"
        content.sound = .default

        let interval: TimeInterval

        switch plant.wateringDays {
        case "Every 2 days":
            interval = 2 * 24 * 60 * 60
        case "Once a week":
            interval = 7 * 24 * 60 * 60
        default:
            interval = 24 * 60 * 60
        }

        let trigger = UNTimeIntervalNotificationTrigger(
                    timeInterval: interval,
                    repeats: true
                )
        let request = UNNotificationRequest(
            identifier: (identifier ?? plant.id).uuidString,
            content: content,
            trigger: trigger
        )

        do {
            try await notificationCenter.add(request)
        } catch {
            print("Could not schedule plant reminder: \(error)")
        }
    }

    func cancelReminder(for plant: PlantReminder) {
        notificationCenter.removePendingNotificationRequests(
            withIdentifiers: [plant.id.uuidString]
        )
    }
}
