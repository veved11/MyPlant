import Combine
import Foundation

final class AddReminderViewModel: ObservableObject {
    @Published var plantName: String
    @Published var room: String
    @Published var light: String
    @Published var wateringDays: String
    @Published var waterAmount: String

    let rooms = ["Bedroom", "Kitchen", "Living Room"]
    let lightOptions = ["Full sun", "Partial sun", "Shade"]
    let wateringOptions = ["Every day", "Every 2 days", "Once a week"]
    let waterAmounts = ["20–50 ml", "50–100 ml", "100–200 ml"]

    let isEditing: Bool

    init(plant: PlantReminder? = nil) {
        isEditing = plant != nil
        plantName = plant?.name ?? ""
        room = plant?.room ?? "Bedroom"
        light = plant?.light ?? "Full sun"
        wateringDays = plant?.wateringDays ?? "Every day"
        waterAmount = plant?.waterAmount ?? "20–50 ml"
    }

    var canSave: Bool {
        !plantName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    func makeReminder() -> PlantReminder? {
        let trimmedName = plantName.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !trimmedName.isEmpty else {
            return nil
        }

        return PlantReminder(
            name: trimmedName,
            room: room,
            light: light,
            wateringDays: wateringDays,
            waterAmount: waterAmount
        )
    }
}
